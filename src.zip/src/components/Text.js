import React from 'react'
export default function Text() {
  return (
    <div className='txt'>
      <div>


      </div>
    </div>
  )
}
