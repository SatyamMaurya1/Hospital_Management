import React from 'react'
import Navbar from 'react-bootstrap/Navbar';
import Image from 'react-bootstrap/Image';


export default function Header(props) {
  return (
    <>
  <div align="center" style={{borderColor:"black"}} className='h'>    
  <div style={{backgroundColor:"whitegrey"}}>   <Navbar expand="lg" className="nbar bg-body-primary">
      
<div align="center" className='head'>
          <Image className='head' src="image1/logo0.png" height= "80px"/> </div>
        
        </Navbar>
    
    </div>
 
    </div>
    </>
  

 )
}
