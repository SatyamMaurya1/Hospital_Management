import React from 'react'
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
//import Image from 'react-bootstrap/Image';
export default function Footer() {
  
  
    return (
      <>
      
  
      <Navbar expand="lg" className="bg">
        <Container className='justify-content-center'>

<div><h5>About us</h5></div>
          
  
 </Container>
      </Navbar>
      
      
      
      </>
  )
}
