import React from 'react'
import Sidebar from './Sidebar'
export default function Vappoint() {
  return (
    <div>
      <Sidebar/>
      <h1>view previous Appointment</h1>
    </div>
  )
}
